<div>
    <h1>User Dashboard</h1>
</div>
<?php /**PATH D:\Work\salammarket\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>
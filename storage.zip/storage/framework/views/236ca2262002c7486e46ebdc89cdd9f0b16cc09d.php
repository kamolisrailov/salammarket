<div class="wrap-icon-section wishlist">
    <a href="<?php echo e(route('product.whishlist')); ?>" class="link-direction">
        <i class="fa fa-heart" aria-hidden="true"></i>
        <div class="left-info">
            <?php if(Cart::instance('whishlist')->count()>0): ?>
            <span class="index"><?php echo e(Cart::instance('whishlist')->count()); ?> item</span>
            <?php endif; ?>
            <span class="title">Wishlist</span>
        </div>
    </a>
</div>
<?php /**PATH D:\Work\salammarket\resources\views/livewire/whishlist-count-component.blade.php ENDPATH**/ ?>